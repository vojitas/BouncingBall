var searchData=
[
  ['settings_144',['Settings',['../menustate_8h.html#af409d79c8e5111545791e6b086b7f0b9af4f70727dc34561dfde1a3c529b6205c',1,'menustate.h']]]
];
