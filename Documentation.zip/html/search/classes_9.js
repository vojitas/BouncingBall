var searchData=
[
  ['settingsstate_82',['SettingsState',['../class_settings_state.html',1,'']]]
];
