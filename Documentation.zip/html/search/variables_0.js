var searchData=
[
  ['ballvelocity_128',['ballVelocity',['../struct_config.html#af4a44fe6d11db2a9cdd3d2fd8c15b02a',1,'Config']]]
];
