var indexSectionsWithContent =
{
  0: "abcdeghiklmprstuw",
  1: "abcgklmprs",
  2: "abcglmprs",
  3: "bdghilmruw",
  4: "bckrstw",
  5: "ms",
  6: "ehmps"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator"
};

