var searchData=
[
  ['racketvelocity_132',['racketVelocity',['../struct_config.html#a8f0b1673300a93bd075a67fc376489e6',1,'Config']]]
];
