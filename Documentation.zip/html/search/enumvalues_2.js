var searchData=
[
  ['medium_142',['Medium',['../settingsstate_8h.html#a8e3d085e7944794cad44a5201a37b141a87f8a6ab85c9ced3702b4ea641ad4bb5',1,'settingsstate.h']]]
];
