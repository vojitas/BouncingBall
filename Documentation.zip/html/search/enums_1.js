var searchData=
[
  ['settingsbutton_138',['SettingsButton',['../settingsstate_8h.html#a8e3d085e7944794cad44a5201a37b141',1,'settingsstate.h']]]
];
